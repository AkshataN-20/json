import { createSimpleComponent } from '@duik/create-simple-component';

export const ModalTitle = createSimpleComponent({
  Component: 'h2',
  displayName: 'ModalTitle',
});
