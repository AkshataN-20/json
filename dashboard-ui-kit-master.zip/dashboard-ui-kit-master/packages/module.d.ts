declare module '*.module.css';

declare module '*.module.scss';

declare module '*.module.sass';

declare module '*.css';

declare module '*.scss';

declare module '*.sass';