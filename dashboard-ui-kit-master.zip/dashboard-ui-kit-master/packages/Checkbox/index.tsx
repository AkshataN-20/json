import { BaseInput } from "@duik/base-input";

export const Checkbox = BaseInput;

Checkbox.displayName = "Checkbox";

export default Checkbox;
